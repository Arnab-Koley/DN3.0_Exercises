package com.library.service;

public class BookService {
	
	public void getBooks() {
		System.out.println("Getting Books from BookService...");
	}

}
