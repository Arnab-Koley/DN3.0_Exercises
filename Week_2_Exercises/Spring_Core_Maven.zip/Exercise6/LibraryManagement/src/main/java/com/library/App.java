package com.library;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.services.BookService;


public class App 
{
    public static void main( String[] args )
    {
    	ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
        BookService bookService = context.getBean(BookService.class);
        
        if (bookService != null) {
            System.out.println("BookService bean is successfully created.");
        } else {
            System.out.println("BookService bean creation failed");
        }
        context.close();
    }
}





