package com.employeemanagement.projection;

import com.employeemanagement.entity.Employee;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

// Class-based projection for Employee entity
@Projection(name = "employeeSummary", types = { Employee.class })
public class EmployeeSummary {

    @Value("#{target.id}")
    private Long id;

    @Value("#{target.name}")
    private String name;

    @Value("#{target.email}")
    private String email;

    @Value("#{target.department.name}")
    private String departmentName;

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartmentName() {
        return departmentName;
    }
}
