package com.employeemanagement.repository;

import com.employeemanagement.entity.Department;
import com.employeemanagement.projection.DepartmentSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    Optional<Department> findByName(String name);

    @Query("SELECT d FROM Department d WHERE d.name = :name")
    Optional<Department> findByNameUsingQuery(@Param("name") String name);

    @Query("SELECT d FROM Department d")
    List<DepartmentSummary> findDepartmentSummaries();
}
