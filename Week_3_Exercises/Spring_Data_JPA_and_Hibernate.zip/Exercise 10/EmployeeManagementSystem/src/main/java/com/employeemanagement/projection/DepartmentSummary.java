package com.employeemanagement.projection;

import com.employeemanagement.entity.Department;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

@Projection(name = "departmentSummary", types = { Department.class })
public class DepartmentSummary {

    @Value("#{target.id}")
    private Long id;

    @Value("#{target.name}")
    private String name;

    @Value("#{target.employees.size()}")
    private Long numberOfEmployees;

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Long getNumberOfEmployees() {
        return numberOfEmployees;
    }
}
