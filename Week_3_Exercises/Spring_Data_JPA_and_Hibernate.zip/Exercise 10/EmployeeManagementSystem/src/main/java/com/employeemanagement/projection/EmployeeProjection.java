package com.employeemanagement.projection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import com.employeemanagement.entity.Employee;

@Projection(name = "employeeProjection", types = { Employee.class })
public interface EmployeeProjection {

    @Value("#{target.id}")
    Long getId();

    @Value("#{target.name}")
    String getName();

    @Value("#{target.email}")
    String getEmail();
    
    @Value("#{target.department.name}")
    String getDepartmentName();
}
