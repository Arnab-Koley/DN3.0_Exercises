package com.employeemanagement.projection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import com.employeemanagement.entity.Department;

@Projection(name = "departmentProjection", types = { Department.class })
public interface DepartmentProjection {

    @Value("#{target.id}")
    Long getId();

    @Value("#{target.name}")
    String getName();
    
    @Value("#{target.employees.size()}")
    Long getNumberOfEmployees();
}
