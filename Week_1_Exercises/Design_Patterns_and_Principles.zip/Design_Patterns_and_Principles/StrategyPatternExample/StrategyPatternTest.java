public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        context.setPaymentStrategy(new CreditCardPayment("1234-5678-9999-1234", "Virat Kholi"));
        context.executePayment(250.75);

        context.setPaymentStrategy(new PayPalPayment("rohit.sharma@gamil.com"));
        context.executePayment(120.00);
    }
}
